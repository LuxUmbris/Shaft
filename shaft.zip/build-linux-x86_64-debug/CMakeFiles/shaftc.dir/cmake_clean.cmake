file(REMOVE_RECURSE
  "CMakeFiles/shaftc.dir/link.d"
  "CMakeFiles/shaftc.dir/src/checker.cpp.o"
  "CMakeFiles/shaftc.dir/src/checker.cpp.o.d"
  "CMakeFiles/shaftc.dir/src/codegen.cpp.o"
  "CMakeFiles/shaftc.dir/src/codegen.cpp.o.d"
  "CMakeFiles/shaftc.dir/src/error.cpp.o"
  "CMakeFiles/shaftc.dir/src/error.cpp.o.d"
  "CMakeFiles/shaftc.dir/src/lexer.cpp.o"
  "CMakeFiles/shaftc.dir/src/lexer.cpp.o.d"
  "CMakeFiles/shaftc.dir/src/main.cpp.o"
  "CMakeFiles/shaftc.dir/src/main.cpp.o.d"
  "CMakeFiles/shaftc.dir/src/parser.cpp.o"
  "CMakeFiles/shaftc.dir/src/parser.cpp.o.d"
  "shaftc"
  "shaftc.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/shaftc.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
