# Empty dependencies file for shaftc.
# This may be replaced when dependencies are built.
