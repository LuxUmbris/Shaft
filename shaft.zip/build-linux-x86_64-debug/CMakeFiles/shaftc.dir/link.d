shaftc: \
  /lib/x86_64-linux-gnu/Scrt1.o \
  /lib/x86_64-linux-gnu/crti.o \
  /usr/lib/gcc/x86_64-linux-gnu/15/crtbeginS.o \
  CMakeFiles/shaftc.dir/src/main.cpp.o \
  CMakeFiles/shaftc.dir/src/lexer.cpp.o \
  CMakeFiles/shaftc.dir/src/parser.cpp.o \
  CMakeFiles/shaftc.dir/src/checker.cpp.o \
  CMakeFiles/shaftc.dir/src/codegen.cpp.o \
  CMakeFiles/shaftc.dir/src/error.cpp.o \
  /usr/lib/llvm-21/lib/libLLVM.so.1 \
  /usr/lib/gcc/x86_64-linux-gnu/15/libstdc++.so \
  /lib/x86_64-linux-gnu/libm.so \
  /lib/x86_64-linux-gnu/libm.so \
  /lib/x86_64-linux-gnu/libm.so \
  /usr/lib/x86_64-linux-gnu/libm.so.6 \
  /usr/lib/x86_64-linux-gnu/libmvec.so.1 \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so \
  /lib/x86_64-linux-gnu/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a \
  /lib/x86_64-linux-gnu/libc.so \
  /lib/x86_64-linux-gnu/libc.so \
  /lib/x86_64-linux-gnu/libc.so \
  /usr/lib/x86_64-linux-gnu/libc.so.6 \
  /usr/lib/x86_64-linux-gnu/libc_nonshared.a \
  /lib64/ld-linux-x86-64.so.2 \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so \
  /lib/x86_64-linux-gnu/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/15/crtendS.o \
  /lib/x86_64-linux-gnu/crtn.o \
  /usr/lib/i386-linux-gnu/libffi.so.8 \
  /usr/lib/x86_64-linux-gnu/libffi.so.8 \
  /usr/lib/i386-linux-gnu/libedit.so.2 \
  /usr/lib/x86_64-linux-gnu/libedit.so.2 \
  /usr/lib/i386-linux-gnu/libz.so.1 \
  /usr/lib/x86_64-linux-gnu/libz.so.1 \
  /usr/lib/i386-linux-gnu/libzstd.so.1 \
  /usr/lib/x86_64-linux-gnu/libzstd.so.1 \
  /usr/lib/i386-linux-gnu/libxml2.so.16 \
  /usr/lib/x86_64-linux-gnu/libxml2.so.16 \
  /lib64/ld-linux-x86-64.so.2 \
  /usr/lib/i386-linux-gnu/libtinfo.so.6 \
  /usr/lib/x86_64-linux-gnu/libtinfo.so.6 \
  /usr/lib/i386-linux-gnu/libbsd.so.0 \
  /usr/lib/x86_64-linux-gnu/libbsd.so.0 \
  /usr/lib/i386-linux-gnu/libmd.so.0 \
  /usr/lib/x86_64-linux-gnu/libmd.so.0

/lib/x86_64-linux-gnu/Scrt1.o:

/lib/x86_64-linux-gnu/crti.o:

/usr/lib/gcc/x86_64-linux-gnu/15/crtbeginS.o:

CMakeFiles/shaftc.dir/src/main.cpp.o:

CMakeFiles/shaftc.dir/src/lexer.cpp.o:

CMakeFiles/shaftc.dir/src/parser.cpp.o:

CMakeFiles/shaftc.dir/src/checker.cpp.o:

CMakeFiles/shaftc.dir/src/codegen.cpp.o:

CMakeFiles/shaftc.dir/src/error.cpp.o:

/usr/lib/llvm-21/lib/libLLVM.so.1:

/usr/lib/gcc/x86_64-linux-gnu/15/libstdc++.so:

/lib/x86_64-linux-gnu/libm.so:

/lib/x86_64-linux-gnu/libm.so:

/lib/x86_64-linux-gnu/libm.so:

/usr/lib/x86_64-linux-gnu/libm.so.6:

/usr/lib/x86_64-linux-gnu/libmvec.so.1:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so:

/lib/x86_64-linux-gnu/libgcc_s.so.1:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a:

/lib/x86_64-linux-gnu/libc.so:

/lib/x86_64-linux-gnu/libc.so:

/lib/x86_64-linux-gnu/libc.so:

/usr/lib/x86_64-linux-gnu/libc.so.6:

/usr/lib/x86_64-linux-gnu/libc_nonshared.a:

/lib64/ld-linux-x86-64.so.2:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so:

/lib/x86_64-linux-gnu/libgcc_s.so.1:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/15/crtendS.o:

/lib/x86_64-linux-gnu/crtn.o:

/usr/lib/i386-linux-gnu/libffi.so.8:

/usr/lib/x86_64-linux-gnu/libffi.so.8:

/usr/lib/i386-linux-gnu/libedit.so.2:

/usr/lib/x86_64-linux-gnu/libedit.so.2:

/usr/lib/i386-linux-gnu/libz.so.1:

/usr/lib/x86_64-linux-gnu/libz.so.1:

/usr/lib/i386-linux-gnu/libzstd.so.1:

/usr/lib/x86_64-linux-gnu/libzstd.so.1:

/usr/lib/i386-linux-gnu/libxml2.so.16:

/usr/lib/x86_64-linux-gnu/libxml2.so.16:

/lib64/ld-linux-x86-64.so.2:

/usr/lib/i386-linux-gnu/libtinfo.so.6:

/usr/lib/x86_64-linux-gnu/libtinfo.so.6:

/usr/lib/i386-linux-gnu/libbsd.so.0:

/usr/lib/x86_64-linux-gnu/libbsd.so.0:

/usr/lib/i386-linux-gnu/libmd.so.0:

/usr/lib/x86_64-linux-gnu/libmd.so.0:
