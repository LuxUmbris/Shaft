
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/vince/dev/repos/Shaft-bootstrap/src/checker.cpp" "CMakeFiles/shaftc.dir/src/checker.cpp.o" "gcc" "CMakeFiles/shaftc.dir/src/checker.cpp.o.d"
  "/home/vince/dev/repos/Shaft-bootstrap/src/codegen.cpp" "CMakeFiles/shaftc.dir/src/codegen.cpp.o" "gcc" "CMakeFiles/shaftc.dir/src/codegen.cpp.o.d"
  "/home/vince/dev/repos/Shaft-bootstrap/src/error.cpp" "CMakeFiles/shaftc.dir/src/error.cpp.o" "gcc" "CMakeFiles/shaftc.dir/src/error.cpp.o.d"
  "/home/vince/dev/repos/Shaft-bootstrap/src/lexer.cpp" "CMakeFiles/shaftc.dir/src/lexer.cpp.o" "gcc" "CMakeFiles/shaftc.dir/src/lexer.cpp.o.d"
  "/home/vince/dev/repos/Shaft-bootstrap/src/main.cpp" "CMakeFiles/shaftc.dir/src/main.cpp.o" "gcc" "CMakeFiles/shaftc.dir/src/main.cpp.o.d"
  "/home/vince/dev/repos/Shaft-bootstrap/src/parser.cpp" "CMakeFiles/shaftc.dir/src/parser.cpp.o" "gcc" "CMakeFiles/shaftc.dir/src/parser.cpp.o.d"
  "" "shaftc" "gcc" "CMakeFiles/shaftc.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
